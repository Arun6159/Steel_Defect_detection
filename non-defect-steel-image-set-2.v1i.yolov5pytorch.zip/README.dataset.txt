# non-defect-steel-image-set-2 > 2025-04-06 6:32pm
https://universe.roboflow.com/project-2-5w2qp/non-defect-steel-image-set-2

Provided by a Roboflow user
License: CC BY 4.0

